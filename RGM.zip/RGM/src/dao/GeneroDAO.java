package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.Genero;

public class GeneroDAO {

public void inserir(Genero genero) {
		
		String sql = "INSERT INTO projetoPI.genero(tipo)"+"VALUES(?)";
		
		Connection conn = null;
		PreparedStatement stm = null;
		
		try {
			conn = ConnectionFactory.getConnection();
			stm = conn.prepareStatement(sql);
			
			 stm.setString(1, genero.getTipo());
			 stm.execute();
		}catch (Exception e) {
			 
			 e.printStackTrace();
		}finally{
			 
			try{
				if(stm != null){ 
					stm.close();
				}
				if(conn != null){
					conn.close();
				} 
			}catch(Exception e){	 
				e.printStackTrace();
			}
		}
	}

	public void deletar(int id) {
		
		String sql = "DELETE FROM projetoPI.genero WHERE id_genero = ?";
		
		Connection conn = null;
		PreparedStatement stm = null;
		
		try {
			conn = ConnectionFactory.getConnection();
			stm = conn.prepareStatement(sql);
			
			stm.setInt(1, id);
			stm.execute();
		}catch (Exception e) {
			 
			 e.printStackTrace();
		}finally{
			try {
				 if(stm != null){
					 
					 stm.close();
					 }	
				 if(conn != null){
					 conn.close();
					 }
			}catch(Exception e){
				 
				 e.printStackTrace();
			}
		}
	}

	public void atualizar(Genero genero) {
		String sql = "UPDATE projetoPI.genero SET tipo=? WHERE id_genero=?";
		
		Connection conn = null;
		PreparedStatement stm = null;
		
		try {
			conn = ConnectionFactory.getConnection();
			stm = conn.prepareStatement(sql);
			
			 stm.setString(1, genero.getTipo());
			 stm.setInt(2, genero.getId_genero());
			 stm.execute();
		}catch (Exception e) {
			 
			 e.printStackTrace();
		}finally{
			try {
				 if(stm != null){
					 
					 stm.close();
					 }	
				 if(conn != null){
					 conn.close();
					 }
			}catch(Exception e){
				 
				 e.printStackTrace();
			}
		}
	}
	
	public Genero carregar(int id) {
		Genero genero = new Genero();
		genero.setId_genero(id);
		String sqlSelect = "SELECT tipo FROM projetoPI.genero WHERE genero.id_genero = ?";
		// usando o try with resources do Java 7, que fecha o que abriu
		try (Connection conn = ConnectionFactory.getConnection();
				PreparedStatement stm = conn.prepareStatement(sqlSelect);) {
			stm.setInt(1, genero.getId_genero());
			try (ResultSet rs = stm.executeQuery();) {
				if (rs.next()) {
					genero.setTipo(rs.getString("tipo"));
				} else {
					genero.setId_genero(-1);
					genero.setTipo(null);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (SQLException e1) {
			System.out.print(e1.getStackTrace());
		}
		return genero;
	}

}
