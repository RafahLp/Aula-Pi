package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.Usuario;


public class UsuarioDAO {

	public void inserir(Usuario usuario) {
		
		String sql = "INSERT INTO projetoPI.usuario(nome_usuario, email, senha)"+"VALUES(?,?,?)";
		
		Connection conn = null;
		PreparedStatement stm = null;
		
		try {
			conn = ConnectionFactory.getConnection();
			stm = conn.prepareStatement(sql);
			
			 stm.setString(1, usuario.getNome());
			 stm.setString(2, usuario.getEmail());
			 stm.setString(3, usuario.getSenha());
			 stm.execute();
		}catch (Exception e) {
			 
			 e.printStackTrace();
		}finally{
			 
			try{
				if(stm != null){ 
					stm.close();
				}
				if(conn != null){
					conn.close();
				} 
			}catch(Exception e){	 
				e.printStackTrace();
			}
		}
	}

	public void deletar(int id) {
		
		String sql = "DELETE FROM projetoPI.usuario WHERE id_usuario = ?";
		
		Connection conn = null;
		PreparedStatement stm = null;
		
		try {
			conn = ConnectionFactory.getConnection();
			stm = conn.prepareStatement(sql);
			
			stm.setInt(1, id);
			stm.execute();
		}catch (Exception e) {
			 
			 e.printStackTrace();
		}finally{
			try {
				 if(stm != null){
					 
					 stm.close();
					 }	
				 if(conn != null){
					 conn.close();
					 }
			}catch(Exception e){
				 
				 e.printStackTrace();
			}
		}
	}

	public void atualizar(Usuario usuario) {
		String sql = "UPDATE projetoPI.usuario SET nome_usuario=?, email=?, senha=? WHERE id_usuario=?";
		
		Connection conn = null;
		PreparedStatement stm = null;
		
		try {
			conn = ConnectionFactory.getConnection();
			stm = conn.prepareStatement(sql);
			
			 stm.setString(1, usuario.getNome());
			 stm.setString(2, usuario.getEmail());
			 stm.setString(3, usuario.getSenha());
			 stm.setInt(4, usuario.getId());
			 stm.execute();
		}catch (Exception e) {
			 
			 e.printStackTrace();
		}finally{
			try {
				 if(stm != null){
					 
					 stm.close();
					 }	
				 if(conn != null){
					 conn.close();
					 }
			}catch(Exception e){
				 
				 e.printStackTrace();
			}
		}
	}
	
	public Usuario carregar(int id) {
		Usuario usuario = new Usuario();
		usuario.setId(id);
		String sqlSelect = "SELECT nome_usuario, email, senha FROM projetoPI.usuario WHERE usuario.id_usuario = ?";
		// usando o try with resources do Java 7, que fecha o que abriu
		try (Connection conn = ConnectionFactory.getConnection();
				PreparedStatement stm = conn.prepareStatement(sqlSelect);) {
			stm.setInt(1, usuario.getId());
			try (ResultSet rs = stm.executeQuery();) {
				if (rs.next()) {
					usuario.setNome(rs.getString("nome_usuario"));
					usuario.setEmail(rs.getString("email"));
					usuario.setSenha(rs.getString("senha"));
				} else {
					usuario.setId(-1);
					usuario.setNome(null);
					usuario.setEmail(null);
					usuario.setSenha(null);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (SQLException e1) {
			System.out.print(e1.getStackTrace());
		}
		return usuario;
	}

}
