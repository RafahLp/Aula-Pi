package dao;

import java.sql.*;

public class ConnectionFactory {
 static String status="";
 
 public static Connection getConnection() {
	 Connection conn=null;
	 try {
		 Class.forName("com.mysql.cj.jdbc.Driver");
		 

String servidor = "localhost";
	      String porta = "3306";
	      String database = "projetoPI";
	      conn =DriverManager.getConnection("jdbc:mysql://"+servidor+":"+porta+"/"+database+"?useSSL=false&serverTimezone=UTC", "Giovanna", "Fiellhp.1910");
		 
		 status = "Conexao aberta";
		 
		 status = "Conexao aberta";
	 }catch (SQLException e) {
		 status = e.getMessage();
		 
	 }catch (ClassNotFoundException e) {
		 status = e.getMessage();
		 
	 }catch (Exception e) {
		 status = e.getMessage();
	 
	 }return conn;
 }
}
