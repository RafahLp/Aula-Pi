package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.Genero;
import model.Livro;

public class LivroDAO {

public void inserir(Livro livro) {
		
		String sql = "INSERT INTO projetoPI.livro(isbn, titulo, autor, editora, preco, genero_id_genero)"+"VALUES(?,?,?,?,?,?)";
		
		Connection conn = null;
		PreparedStatement stm = null;
		
		try {
			conn = ConnectionFactory.getConnection();
			stm = conn.prepareStatement(sql);
			
			 stm.setInt(1, livro.getIsbn());
			 stm.setString(2, livro.getTitulo());
			 stm.setString(3, livro.getAutor());
			 stm.setString(4, livro.getEditora());
			 stm.setDouble(5, livro.getPreco());
			 stm.setInt(6, livro.getGenero().getId_genero());

			 stm.execute();
		}catch (Exception e) {
			 
			 e.printStackTrace();
		}finally{
			 
			try{
				if(stm != null){ 
					stm.close();
				}
				if(conn != null){
					conn.close();
				} 
			}catch(Exception e){	 
				e.printStackTrace();
			}
		}
	}

	public void deletar(int id) {
		
		String sql = "DELETE FROM projetoPI.livro WHERE id_livro = ?";
		
		Connection conn = null;
		PreparedStatement stm = null;
		
		try {
			conn = ConnectionFactory.getConnection();
			stm = conn.prepareStatement(sql);
			
			stm.setInt(1, id);
			stm.execute();
		}catch (Exception e) {
			 
			 e.printStackTrace();
		}finally{
			try {
				 if(stm != null){
					 
					 stm.close();
					 }	
				 if(conn != null){
					 conn.close();
					 }
			}catch(Exception e){
				 
				 e.printStackTrace();
			}
		}
	}

	public void atualizar(Livro livro) {
		String sql = "UPDATE projetoPI.livro SET isbn=?, titulo=?, autor=?, editora=?, preco=?, genero_id_genero=? WHERE id_livro=?";
		
		Connection conn = null;
		PreparedStatement stm = null;
		
		try {
			conn = ConnectionFactory.getConnection();
			stm = conn.prepareStatement(sql);
			
			 stm.setInt(1, livro.getIsbn());
			 stm.setString(2, livro.getTitulo());
			 stm.setString(3, livro.getAutor());
			 stm.setString(4, livro.getEditora());
			 stm.setDouble(5, livro.getPreco());
			 stm.setInt(6, livro.getGenero().getId_genero());
			 stm.setInt(7, livro.getId_livro());
			 stm.execute();
		}catch (Exception e) {
			 
			 e.printStackTrace();
		}finally{
			try {
				 if(stm != null){
					 
					 stm.close();
					 }	
				 if(conn != null){
					 conn.close();
					 }
			}catch(Exception e){
				 
				 e.printStackTrace();
			}
		}
	}
	
	public Livro carregar(int id) {
		Livro livro = new Livro();
		livro.setId_livro(id);
		String sqlSelect = "SELECT isbn, titulo, autor, editora, preco, tipo FROM  projetoPI.livro l inner join projetoPI.genero g on l.id_livro=g.id_genero WHERE id_livro=?";
		// usando o try with resources do Java 7, que fecha o que abriu
		try (Connection conn = ConnectionFactory.getConnection();
				PreparedStatement stm = conn.prepareStatement(sqlSelect);) {
			stm.setInt(1, livro.getId_livro());
			try (ResultSet rs = stm.executeQuery();) {
				while(rs.next()) {
					livro.setIsbn(rs.getInt("isbn"));
					livro.setTitulo(rs.getString("titulo"));
					livro.setAutor(rs.getString("autor"));
					livro.setEditora(rs.getString("editora"));
					livro.setPreco(rs.getDouble("preco"));
					
					Genero genero= new Genero();
					genero.setTipo(rs.getString("tipo"));
					livro.setGenero(genero);
					
				}/* else {
					livro.setId_livro(-1);
					livro.setIsbn((Integer) null);
					livro.setTitulo(null);
					livro.setAutor(null);
					livro.setEditora(null);
					livro.setPreco((Double) null);
					livro.setGenero(null);
				}*/
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (SQLException e1) {
			System.out.print(e1.getStackTrace());
		}
		return livro;
	}
}
