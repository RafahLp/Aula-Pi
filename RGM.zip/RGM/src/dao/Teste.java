package dao;

import dao.ConnectionFactory;

public class Teste {

	public static void main(String[] args) {

				ConnectionFactory.getConnection();
				System.out.println(ConnectionFactory.status);
			
	}

}

