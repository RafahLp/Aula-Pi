package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Genero;
import model.Livro;
import service.GeneroService;
import service.LivroService;


/**
 * Servlet implementation class ManterLivrsController
 */
@WebServlet("/ManterLivro.do")
public class ManterLivroController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
    
    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int pIsbn = Integer.parseInt(request.getParameter("isbn"));
        String pTitulo = request.getParameter("titulo");
        String pAutor = request.getParameter("autor");
        String pEditora = request.getParameter("editora");
        double pPreco = Double.parseDouble(request.getParameter("preco"));
        String pTipo = request.getParameter("tipo");
       
        
        //instanciar o javabean
        Livro livro = new Livro();
        livro.setIsbn(pIsbn);
        livro.setTitulo(pTitulo);
        livro.setAutor(pAutor);
        livro.setEditora(pEditora);
        livro.setPreco(pPreco);
        
        Genero genero = new Genero();
        genero.setTipo(pTipo);

        
        //instanciar o service
        LivroService ls = new LivroService();
        ls.inserir(livro);
        livro = ls.carregar(livro.getId_livro());
        GeneroService gs = new GeneroService();
        gs.inserir(genero);
        genero = gs.carregar(genero.getId_genero());
        
        //enviar para o jsp
        request.setAttribute("livro", livro);
        request.setAttribute("genero", genero);
        
        RequestDispatcher view = 
        request.getRequestDispatcher("Livro.jsp");
        request.getRequestDispatcher("Genero.jsp");
        view.forward(request, response);
        
    }
    
}
