package service;

import dao.LivroDAO;
import model.Livro;

public class LivroService {
	LivroDAO dao = new LivroDAO();
	
	public void inserir(Livro livro) {
		dao.inserir(livro);
	}
	
	public void atualizar(Livro livro){
		dao.atualizar(livro);
	}
	
	public void deletar(int id){
		dao.deletar(id);
	}
	
	public Livro carregar(int id){
		return dao.carregar(id);
	}
}
