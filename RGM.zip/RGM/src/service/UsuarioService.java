package service;

import model.Usuario;
import dao.UsuarioDAO;


public class UsuarioService {
	UsuarioDAO dao = new UsuarioDAO();
	
	public void inserir(Usuario usuario) {
		dao.inserir(usuario);
	}
	
	public void atualizar(Usuario usuario){
		dao.atualizar(usuario);
	}
	
	public void deletar(int id){
		dao.deletar(id);
	}
	
	public Usuario carregar(int id){
		return dao.carregar(id);
	}

}
