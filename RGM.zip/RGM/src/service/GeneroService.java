package service;

import dao.GeneroDAO;
import model.Genero;

public class GeneroService {
	GeneroDAO dao = new GeneroDAO();
	
	public void inserir(Genero genero) {
		dao.inserir(genero);
	}
	
	public void atualizar(Genero genero){
		dao.atualizar(genero);
	}
	
	public void deletar(int id){
		dao.deletar(id);
	}
	
	public Genero carregar(int id){
		return dao.carregar(id);
	}
}
