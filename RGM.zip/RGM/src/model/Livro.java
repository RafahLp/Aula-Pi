package model;

public class Livro {

	private int id_livro;
	private int isbn;
	private String titulo;
	private String autor;
	private String editora;
	private double preco;
	private Genero genero;
	
	public Livro() {
	}

	public Livro(int id_livro, int isbn, String titulo, String autor, String editora, double preco, Genero genero) {
		this.id_livro = id_livro;
		this.isbn = isbn;
		this.titulo = titulo;
		this.autor = autor;
		this.editora = editora;
		this.preco = preco;
		this.genero = genero;
	}

	public int getId_livro() {
		return id_livro;
	}


	public void setId_livro(int id_livro) {
		this.id_livro = id_livro;
	}


	public int getIsbn() {
		return isbn;
	}


	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}


	public String getTitulo() {
		return titulo;
	}


	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}


	public String getAutor() {
		return autor;
	}


	public void setAutor(String autor) {
		this.autor = autor;
	}


	public String getEditora() {
		return editora;
	}


	public void setEditora(String editora) {
		this.editora = editora;
	}


	public double getPreco() {
		return preco;
	}


	public void setPreco(double preco) {
		this.preco = preco;
	}

	public Genero getGenero() {
		return genero;
	}


	public void setGenero(Genero genero) {
		this.genero = genero;
	}

	@Override
	public String toString() {
		return "Livro [id_livro=" + id_livro + ", isbn=" + isbn + ", titulo=" + titulo + ", autor=" + autor
				+ ", editora=" + editora + ", preco=" + preco + ", genero=" + genero + "]";
	}





	
	
}
